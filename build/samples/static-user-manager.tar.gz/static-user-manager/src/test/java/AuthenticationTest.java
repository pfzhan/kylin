import org.junit.Assert;
import org.junit.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

public class AuthenticationTest {

    @Test
    public void testBasic() {
        StaticAuthenticationProvider provider = new StaticAuthenticationProvider();
        // username is test
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("test", "test");
        Assert.assertTrue(!provider.authenticateImpl(token));
        // username contain test
        token = new UsernamePasswordAuthenticationToken("test1", "test");
        Assert.assertTrue(!provider.authenticateImpl(token));
        // username don't contain test
        token = new UsernamePasswordAuthenticationToken("abc", "test");
        Assert.assertTrue(provider.authenticateImpl(token));
    }
}
